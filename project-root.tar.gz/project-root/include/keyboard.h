#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <stdint.h>

uint8_t scan(void);

extern char charmap[];

#endif

