nclude "console.h"

char* const VGA_BUFFER = (char*) 0xb8000;  Pointer to the memory address of the VGA buffer
					   VGA_Color terminal_font_color = LIGHT_GRAY; // Default font color
					   VGA_Color terminal_background_color = BLACK; // Default background color
					   int terminal_position = 0; // Tracks where the next print should go
void clear_terminal() {
	    for (int i = 0; i < VGA_HEIGHT * VGA_WIDTH * 2; i += 2) {
		            VGA_BUFFER[i] = 0; // Clear the character
					                VGA_BUFFER[i + 1] = 0x07; // Set the default color (light gray)
					                    }
					                    }
					       void set_terminal_font_color(VGA_Color col) {
					      terminal_font_color = col;
					       }

void set_terminal_background_color(VGA_Color col) {
	    terminal_background_color = col;
}
void print_character(char c) {
	    print_character_with_color(c, terminal_background_color, terminal_font_color);
}
void print_line_with_color(char* str, VGA_Color bg_color, VGA_Color font_color) {
	    print_string_with_color(str, bg_color, font_color);
	        print_character_with_color('\n', bg_color, font_color); // Add newline at the end
									 }
									void print_character_with_color(char c, VGA_Color bg_color, VGA_Color font_color) {
									           if (c == '\n') {
										           Move to the next line: reset to the next multiple of 160
											            terminal_position = (terminal_position / 160 + 1) * 160;
											                    return;
											                        }
											   
											                            // Place the character and set the style byte
											                                VGA_BUFFER[terminal_position++] = c;
											                                    VGA_BUFFER[terminal_position++] = (bg_color << 4) | font_color;
											                                    }

#include "console.h"

void main() {
	    clear_terminal();
	        print_string_with_color("Hello", YELLOW, CYAN);
		    print_line_with_color("World", MAGENTA, GREEN);
		        print_string("Today");
			    return;
}


