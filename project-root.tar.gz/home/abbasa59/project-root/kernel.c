#include "keyboard.h"
#include "portmap.h"
#include <stdint.h>

extern char charmap[]; // Use downloaded charmap
		       
		        void clear_terminal();
		        void print_character(char c);
		       
		        void kernel_main() {
		            clear_terminal();
		       
		                uint8_t byte;
		                    while (1) {
		                            while ((byte = scan())) {
		                                        print_character(charmap[byte]);
		                                                }
		                                                    }
		                                                    }
		       
