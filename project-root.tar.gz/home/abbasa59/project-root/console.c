#include "portmap.h"
#include <stdint.h>

extern uint16_t terminal_position;

void update_cursor() {
	    uint16_t cursor_position = terminal_position >> 1;

	        outb(0x3D4, 0x0F);
		    outb(0x3D5, (uint8_t)(cursor_position));

		        outb(0x3D4, 0x0E);
			    outb(0x3D5, (uint8_t)(cursor_position >> 8));
}

void clear_terminal() {
	    terminal_position = 0;
	        update_cursor();
}

void print_character_with_color(char character, uint8_t color) {
	    (void)character; // Suppress unused parameter warning
			          (void)color;     // Suppress unused parameter warning
			     
			              update_cursor();
			              }
			     
